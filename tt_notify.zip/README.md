# 🔔 tt_notify — Dynamic Audio-Synthesized Notification Bus
[![FiveM](https://img.shields.io/badge/FiveM-Resource-blue.svg?style=for-the-badge)](https://fivem.net/)
[![UI](https://img.shields.io/badge/UI-React%2018%20%7C%20Tailwind-purple.svg?style=for-the-badge)](https://github.com/)
[![Performance](https://img.shields.io/badge/Resmon-0.00ms-brightgreen.svg?style=for-the-badge)](https://github.com/)

Modern, customizable notification system with procedural WebAudio sound synthesis, stackable glassmorphic toasts, and zero external CDN dependencies.

## 🚀 Key Features
- **Procedural WebAudio Synthesis:** Generates high-fidelity feedback frequencies client-side without external audio files.
- **Stackable Notification Queue:** Auto-dismissing banners with smooth CSS entry/exit transitions.
- **Type Support:** `success`, `error`, `inform`, `warning`, `police`, `ambulance`.
- **100% Offline:** Built with local React 18 and Tailwind CSS.

## 🔌 Client & Server Usage
```lua
-- Client Trigger
exports['tt_notify']:Notify('Transaction Approved', 'success', 5000)

-- Server Broadcast
TriggerClientEvent('tt_notify:client:send', targetSource, {
    title = 'Bank Deposit',
    description = 'Received $5,000 from Government Grant.',
    type = 'success',
    duration = 6000
})
```
