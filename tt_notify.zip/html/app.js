class NotifySoundEngine {
    constructor() {
        this.ctx = null;
    }

    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioCtx();
        }
        if (this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    play(type) {
        this.init();
        if (!this.ctx) return;
        const now = this.ctx.currentTime;

        if (type === 'success') {
            [523.25, 659.25].forEach((f, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(f, now + (i * 0.08));
                gain.gain.setValueAtTime(0.15, now + (i * 0.08));
                gain.gain.exponentialRampToValueAtTime(0.001, now + (i * 0.08) + 0.14);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now + (i * 0.08));
                osc.stop(now + (i * 0.08) + 0.14);
            });
        } else if (type === 'error') {
            [220, 180].forEach((f, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(f, now + (i * 0.09));
                gain.gain.setValueAtTime(0.18, now + (i * 0.09));
                gain.gain.exponentialRampToValueAtTime(0.001, now + (i * 0.09) + 0.15);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now + (i * 0.09));
                osc.stop(now + (i * 0.09) + 0.15);
            });
        } else if (type === 'warning') {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(440, now);
            osc.frequency.setValueAtTime(370, now + 0.1);
            gain.gain.setValueAtTime(0.16, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.22);
        } else if (type === 'level_up') {
            [440, 554.37, 659.25, 880].forEach((f, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(f, now + (i * 0.07));
                gain.gain.setValueAtTime(0.2, now + (i * 0.07));
                gain.gain.exponentialRampToValueAtTime(0.001, now + (i * 0.07) + 0.18);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now + (i * 0.07));
                osc.stop(now + (i * 0.07) + 0.18);
            });
        } else {
            // Inform / Info
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(700, now);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.12);
        }
    }
}

const audio = new NotifySoundEngine();
const container = document.getElementById('notify-container');

const defaultIcons = {
    'success': 'fa-solid fa-circle-check',
    'error': 'fa-solid fa-circle-xmark',
    'warning': 'fa-solid fa-triangle-exclamation',
    'inform': 'fa-solid fa-circle-info',
    'info': 'fa-solid fa-circle-info',
    'level_up': 'fa-solid fa-star'
};

function createNotification(data) {
    const type = (data.type || 'inform').toLowerCase();
    const title = data.title || (type.toUpperCase());
    const desc = data.description || data.message || '';
    const duration = data.duration || 5000;
    const icon = data.icon || defaultIcons[type] || 'fa-solid fa-bell';

    // Play Audio Cue
    if (data.sound !== false) {
        audio.play(type);
    }

    const card = document.createElement('div');
    card.className = `toast-card toast-${type}`;

    const inner = document.createElement('div');
    inner.className = 'toast-inner';

    const iconWrap = document.createElement('div');
    iconWrap.className = 'toast-icon-wrap';
    const iconEl = document.createElement('i');
    iconEl.className = icon;
    iconWrap.appendChild(iconEl);

    const content = document.createElement('div');
    content.className = 'toast-content';

    const header = document.createElement('div');
    header.className = 'toast-header';

    const titleEl = document.createElement('span');
    titleEl.className = 'toast-title';
    titleEl.textContent = title;

    const timeEl = document.createElement('span');
    timeEl.className = 'toast-time';
    timeEl.textContent = 'JUST NOW';

    header.appendChild(titleEl);
    header.appendChild(timeEl);

    const descEl = document.createElement('div');
    descEl.className = 'toast-desc';
    descEl.textContent = desc;

    content.appendChild(header);
    content.appendChild(descEl);

    inner.appendChild(iconWrap);
    inner.appendChild(content);

    const progress = document.createElement('div');
    progress.className = 'toast-progress';
    const fill = document.createElement('div');
    fill.className = 'toast-progress-fill';
    fill.style.transition = `transform ${duration}ms linear`;
    fill.style.transform = 'scaleX(0)';
    progress.appendChild(fill);

    card.appendChild(inner);
    card.appendChild(progress);

    container.prepend(card);

    // Auto-remove after duration
    setTimeout(() => {
        card.classList.add('removing');
        setTimeout(() => {
            if (card.parentNode) card.parentNode.removeChild(card);
        }, 250);
    }, duration);
}

// NUI Messages
window.addEventListener('message', (e) => {
    const msg = e.data;
    if (!msg) return;

    if (msg.action === 'notify' || msg.action === 'sendAlert') {
        createNotification(msg.data || msg);
    } else if (msg.action === 'setPosition') {
        container.className = `position-${msg.position || 'top-right'}`;
    }
});
