local function SendNotification(src, title, desc, notifType, duration, icon)
    if not src then return end
    TriggerClientEvent('ag_notify:client:SendAlert', src, {
        title = title or 'Notification',
        description = desc or '',
        type = notifType or 'inform',
        duration = duration or 5000,
        icon = icon
    })
end

exports('Notify', SendNotification)
exports('SendAlert', SendNotification)
exports('SendNotification', SendNotification)

RegisterNetEvent('ag_notify:server:SendAlert', function(title, desc, notifType, duration, icon)
    local src = source
    if not src or src <= 0 then return end
    SendNotification(src, title, desc, notifType, duration, icon)
end)

RegisterNetEvent('tt_notify:server:SendAlert', function(title, desc, notifType, duration, icon)
    local src = source
    if not src or src <= 0 then return end
    SendNotification(src, title, desc, notifType, duration, icon)
end)
