# Antigravity Architecture & Guidelines (agents.md)

## 1. Core Principles & Philosophy
* **Pure NUI JavaScript**: Nothing ends up in JavaScript except for pure NUI rendering, Web Audio synthesis, and NUI bridge message handlers (window.addEventListener('message') / etchNui). All game logic, security validation, inventory checks, math calculations, and database queries are strictly enforced in Lua.
* **Framework Agnostic**: Universal multi-framework bridge support (ridge/client.lua, ridge/server.lua) ensuring seamless zero-code-change compatibility across QBCore, QBox, ESX Legacy, and Standalone (ox_core).
* **Safety First (Server Authority)**: Never trust the client. If a script changes an entity position, velocity, balance, or inventory state, the action must be verified and executed server-side.
* **Resmon Target (0.00 ms)**: Idle client performance must remain at 0.00 ms. Utilize event-driven architecture, ox_target interaction zones, and throttled sleep loops.
* **Modular React Architecture**: Utilize modular React components (createElement: h or JSX) to structure UI views, modals, gauges, and keypad controllers.

## 2. Client-Side vs. Server-Side Physics & Authority
* **Entity Synchronization**: Any vehicle/object modification or physical state changes must ensure the local client has network ownership of that specific entity (SetEntityAsMissionEntity, NetworkRequestControlOfEntity, SetNetworkIdCanMigrate).
* **Preventing False Positives with Anti-Cheats**: 
  * Server triggers validate distance, player inventory, and money balance before applying states.
  * Custom events use strict parameter validation so anti-cheat solutions don't mistake custom mechanics for malicious injections.

## 3. Scoping & State Management
* Keep server callbacks (lib.callback.register) and client threads clearly separated to prevent execution context confusion.
* All database transactions utilize parameterized queries (oxmysql) preventing SQL injection.

---
Official Support Discord: https://discord.gg/j6zdXXfZN
