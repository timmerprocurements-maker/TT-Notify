local RegisterNetEvent = RegisterNetEvent
local SendNUIMessage = SendNUIMessage

local function GetDefaultTitle(notifyType)
    local t = string.lower(tostring(notifyType or 'inform'))
    if t == 'success' then return 'SUCCESS'
    elseif t == 'error' then return 'ERROR'
    elseif t == 'warning' then return 'WARNING'
    elseif t == 'police' or t == 'dispatch' then return 'DISPATCH'
    elseif t == 'bank' or t == 'banking' then return 'BANKING'
    elseif t == 'admin' then return 'ADMINISTRATION'
    else return 'INFORMATION'
    end
end

local function SendAlert(title, description, notifyType, duration)
    -- Handle single-argument or swapped title/description calls
    local finalTitle = title
    local finalDesc = description
    local finalType = notifyType or 'inform'
    local finalDuration = tonumber(duration) or 4500

    if not description and title then
        finalTitle = GetDefaultTitle(finalType)
        finalDesc = tostring(title)
    elseif title and (title == 'Notification' or title == '') then
        finalTitle = GetDefaultTitle(finalType)
    end

    SendNUIMessage({
        action = 'notify',
        title = finalTitle,
        description = finalDesc,
        type = finalType,
        duration = finalDuration
    })
end

exports('Notify', SendAlert)
exports('Alert', SendAlert)

RegisterNetEvent('tt_notify:client:SendAlert', function(title, description, notifyType, duration)
    SendAlert(title, description, notifyType, duration)
end)

RegisterNetEvent('ox_lib:notify', function(data)
    if type(data) == 'table' then
        SendAlert(data.title, data.description, data.type, data.duration)
    else
        SendAlert(nil, tostring(data), 'inform', 4500)
    end
end)

RegisterNetEvent('QBCore:Notify', function(text, notifyType, length)
    local nType = notifyType or 'inform'
    SendAlert(GetDefaultTitle(nType), text, nType, length or 4500)
end)

RegisterNetEvent('ag_notify:client:SendAlert', function(title, description, notifyType, duration)
    SendAlert(title, description, notifyType, duration)
end)
